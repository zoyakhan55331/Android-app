package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.components.ActionCard
import com.example.ui.components.AssistantStatusBar
import com.example.ui.components.FuturisticOrb
import com.example.ui.components.HistorySheet
import com.example.ui.components.PermissionDialog
import com.example.ui.components.QuickActionChips
import com.example.ui.components.SettingsDialog
import com.example.ui.components.WaveformVisualizer
import com.example.ui.state.AssistantStatus
import com.example.ui.state.FizaAssistantUiState
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlitchRed
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeuralPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TranslucentCard
import com.example.ui.theme.TranslucentGlass
import com.example.ui.theme.VioletGlow
import com.example.ui.theme.VoidBlack
import com.example.ui.viewmodel.FizaViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: FizaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsState()

                // Permission launcher for Android runtime permissions
                val permissionsToRequest = mutableListOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ).apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }.toTypedArray()

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    checkAndSyncPermissions()
                }

                LaunchedEffect(Unit) {
                    checkAndSyncPermissions()
                }

                FizaMainScreen(
                    uiState = uiState,
                    onOrbClicked = {
                        if (!uiState.hasAudioPermission) {
                            permissionLauncher.launch(permissionsToRequest)
                        } else {
                            viewModel.toggleListening()
                        }
                    },
                    onRequestPermissions = {
                        permissionLauncher.launch(permissionsToRequest)
                    },
                    onQuickAction = { command ->
                        viewModel.sendTextCommand(command)
                    },
                    onSendTextCommand = { text ->
                        viewModel.sendTextCommand(text)
                    },
                    onOpenHistory = { viewModel.showHistoryDialog(true) },
                    onOpenSettings = { viewModel.showSettingsDialog(true) },
                    onOpenPermissions = { viewModel.showPermissionsDialog(true) },
                    onClearHistory = { viewModel.clearHistory() },
                    onLanguageSelected = { viewModel.updateLanguage(it) },
                    onVoiceTuned = { pitch, pace -> viewModel.updateVoiceTuning(pitch, pace) },
                    onToggleBgService = { viewModel.toggleBackgroundService() },
                    onApiKeySaved = { viewModel.setCustomApiKey(it) },
                    onDismissHistory = { viewModel.showHistoryDialog(false) },
                    onDismissSettings = { viewModel.showSettingsDialog(false) },
                    onDismissPermissions = { viewModel.showPermissionsDialog(false) }
                )
            }
        }
    }

    private fun checkAndSyncPermissions() {
        val audio = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val contacts = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val location = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val call = ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        viewModel.updatePermissions(
            audio = audio,
            contacts = contacts,
            location = location,
            notifications = notif,
            call = call
        )
    }
}

@Composable
fun FizaMainScreen(
    uiState: FizaAssistantUiState,
    onOrbClicked: () -> Unit,
    onRequestPermissions: () -> Unit,
    onQuickAction: (String) -> Unit,
    onSendTextCommand: (String) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPermissions: () -> Unit,
    onClearHistory: () -> Unit,
    onLanguageSelected: (String) -> Unit,
    onVoiceTuned: (Float, Float) -> Unit,
    onToggleBgService: () -> Unit,
    onApiKeySaved: (String) -> Unit,
    onDismissHistory: () -> Unit,
    onDismissSettings: () -> Unit,
    onDismissPermissions: () -> Unit
) {
    var textInput by remember { mutableStateOf("") }

    Scaffold(
        containerColor = VoidBlack,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            VoidBlack,
                            CyberDark,
                            Color(0xFF0D0B18),
                            VoidBlack
                        )
                    )
                )
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Top Navigation / Header Bar
                TopAssistantBar(
                    uiState = uiState,
                    onOpenHistory = onOpenHistory,
                    onOpenSettings = onOpenSettings,
                    onOpenPermissions = onOpenPermissions
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Assistant Live Status Badge
                AssistantStatusBar(
                    status = uiState.status,
                    isBackgroundActive = uiState.isBackgroundServiceRunning
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Center Stage: Futuristic Interactive Voice Orb
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    FuturisticOrb(
                        status = uiState.status,
                        audioLevel = uiState.rmsAudioLevel,
                        onClick = onOrbClicked
                    )
                }

                // Live Frequency Equalizer / Waveform Visualizer
                WaveformVisualizer(
                    status = uiState.status,
                    audioLevel = uiState.rmsAudioLevel,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Executed Native Action Card
                ActionCard(
                    toolEvent = uiState.activeTool,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                )

                // Conversational Bubble / Dynamic Response Area
                ResponseCard(
                    status = uiState.status,
                    transcript = uiState.userSpeechTranscript,
                    response = uiState.fizaResponseText,
                    errorMessage = uiState.errorMessage
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Action Chips Row
                QuickActionChips(
                    onChipClicked = onQuickAction
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Text command fallback input bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = {
                            Text("Type command (e.g. Call Dad, Open YouTube)", color = TextMuted, fontSize = 12.sp)
                        },
                        maxLines = 1,
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = CyberBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CyberSurface.copy(alpha = 0.7f),
                            unfocusedContainerColor = CyberSurface.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("text_command_input")
                    )

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                onSendTextCommand(textInput)
                                textInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(NeonCyan)
                            .testTag("send_command_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send Command",
                            tint = VoidBlack,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Modals / Sheets
        if (uiState.showHistorySheet) {
            HistorySheet(
                history = uiState.history,
                onClearHistory = onClearHistory,
                onDismiss = onDismissHistory
            )
        }

        if (uiState.showSettingsSheet) {
            SettingsDialog(
                uiState = uiState,
                onLanguageSelected = onLanguageSelected,
                onVoiceTuned = onVoiceTuned,
                onToggleBackgroundService = onToggleBgService,
                onApiKeySaved = onApiKeySaved,
                onDismiss = onDismissSettings
            )
        }

        if (uiState.showPermissionSheet) {
            PermissionDialog(
                uiState = uiState,
                onRequestPermissions = onRequestPermissions,
                onDismiss = onDismissPermissions
            )
        }
    }
}

@Composable
private fun TopAssistantBar(
    uiState: FizaAssistantUiState,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPermissions: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp)
    ) {
        // Logo & Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(NeonCyan, ElectricViolet, VoidBlack)
                        )
                    )
                    .border(1.5.dp, NeonCyan, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = "Fiza AI Logo",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "FIZA",
                        color = NeonCyan,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "AI",
                        color = ElectricViolet,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                }

                Text(
                    text = "NATIVE VOICE ASSISTANT",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Action Icons
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Permissions indicator icon
            val allPermissionsGranted = uiState.hasAudioPermission && uiState.hasContactsPermission && uiState.hasLocationPermission
            IconButton(
                onClick = onOpenPermissions,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (allPermissionsGranted) CyberSurface else GlitchRed.copy(alpha = 0.2f))
                    .border(1.dp, if (allPermissionsGranted) CyberBorder else GlitchRed, CircleShape)
                    .testTag("permissions_top_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Permissions Status",
                    tint = if (allPermissionsGranted) MatrixGreen else GlitchRed,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Transcript / History Icon
            IconButton(
                onClick = onOpenHistory,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, CircleShape)
                    .testTag("history_top_button")
            ) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "Voice Transcript Logs",
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Settings Icon
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, CircleShape)
                    .testTag("settings_top_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = ElectricViolet,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun ResponseCard(
    status: AssistantStatus,
    transcript: String,
    response: String,
    errorMessage: String?
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(RoundedCornerShape(18.dp))
            .background(TranslucentGlass)
            .border(
                1.dp,
                Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.3f), ElectricViolet.copy(alpha = 0.3f))),
                RoundedCornerShape(18.dp)
            )
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (transcript.isNotBlank() && transcript != "Listening...") {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "YOU SAID:",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "\"$transcript\"",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }

        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "FIZA:",
                color = ElectricViolet,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(top = 2.dp)
            )

            Text(
                text = errorMessage ?: response,
                color = if (errorMessage != null) GlitchRed else TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 20.sp,
                modifier = Modifier.testTag("fiza_response_text")
            )
        }
    }
}
