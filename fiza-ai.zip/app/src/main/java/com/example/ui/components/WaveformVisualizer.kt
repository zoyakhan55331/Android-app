package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.state.AssistantStatus
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeuralPink
import kotlin.math.sin

@Composable
fun WaveformVisualizer(
    status: AssistantStatus,
    audioLevel: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase_oscillator"
    )

    val isActive = status == AssistantStatus.LISTENING || status == AssistantStatus.SPEAKING || status == AssistantStatus.PROCESSING

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        val barCount = 28
        val totalWidth = size.width
        val barWidth = 4.dp.toPx()
        val spacing = (totalWidth - (barCount * barWidth)) / (barCount - 1)
        val maxHeight = size.height

        val colorGradient = when (status) {
            AssistantStatus.LISTENING -> listOf(NeonCyan, MatrixGreen)
            AssistantStatus.SPEAKING -> listOf(NeuralPink, ElectricViolet)
            AssistantStatus.PROCESSING -> listOf(ElectricViolet, NeonCyan)
            else -> listOf(NeonCyan.copy(alpha = 0.3f), ElectricViolet.copy(alpha = 0.3f))
        }

        for (i in 0 until barCount) {
            val x = i * (barWidth + spacing)
            val normalizedIndex = i.toFloat() / barCount.toFloat()

            // Sinusoidal wave envelope
            val envelope = sin(normalizedIndex * Math.PI.toFloat())
            val oscillation = sin(phase + (i * 0.45f)) * 0.5f + 0.5f

            val baseFactor = if (isActive) {
                val reactiveBoost = audioLevel * 0.85f
                (0.15f + (oscillation * 0.35f * envelope) + (reactiveBoost * envelope)).coerceIn(0.08f, 1.0f)
            } else {
                (0.08f + (sin(phase + i) * 0.04f)).coerceIn(0.05f, 0.2f)
            }

            val barHeight = maxHeight * baseFactor
            val top = (maxHeight - barHeight) / 2f

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = colorGradient,
                    startY = top,
                    endY = top + barHeight
                ),
                topLeft = Offset(x, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
