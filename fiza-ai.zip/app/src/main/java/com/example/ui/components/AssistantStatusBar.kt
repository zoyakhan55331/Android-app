package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.state.AssistantStatus
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlitchRed
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeuralPink
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TranslucentCard

@Composable
fun AssistantStatusBar(
    status: AssistantStatus,
    isBackgroundActive: Boolean,
    modifier: Modifier = Modifier
) {
    val statusColor by animateColorAsState(
        targetValue = when (status) {
            AssistantStatus.LISTENING -> NeonCyan
            AssistantStatus.SPEAKING -> NeuralPink
            AssistantStatus.PROCESSING -> ElectricViolet
            AssistantStatus.IDLE -> MatrixGreen
            AssistantStatus.CONNECTING -> CyberAmber
            AssistantStatus.ERROR -> GlitchRed
            AssistantStatus.DISCONNECTED -> Color.Gray
        },
        label = "status_pill_color"
    )

    val statusText = when (status) {
        AssistantStatus.LISTENING -> "LISTENING • 16 kHz PCM"
        AssistantStatus.SPEAKING -> "FIZA SPEAKING • 24 kHz"
        AssistantStatus.PROCESSING -> "REASONING & ROUTING..."
        AssistantStatus.IDLE -> "READY • TAP OR SPEAK"
        AssistantStatus.CONNECTING -> "CONNECTING LIVE SESSION"
        AssistantStatus.ERROR -> "SYSTEM ALERT"
        AssistantStatus.DISCONNECTED -> "STANDBY"
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
            .clip(RoundedCornerShape(30.dp))
            .background(TranslucentCard)
            .border(1.dp, CyberBorder.copy(alpha = 0.8f), RoundedCornerShape(30.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Glowing status dot
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(statusColor)
        )

        Text(
            text = statusText,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.sp
        )

        if (isBackgroundActive) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MatrixGreen.copy(alpha = 0.2f))
                    .border(1.dp, MatrixGreen.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "BG SERVICE ON",
                    color = MatrixGreen,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
