package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.native.NativeActionHandler
import com.example.service.AudioStreamer
import com.example.service.FizaVoiceService
import com.example.service.GeminiService
import com.example.service.TextToSpeechEngine
import com.example.ui.state.AssistantStatus
import com.example.ui.state.ConversationMessage
import com.example.ui.state.FizaAssistantUiState
import com.example.ui.state.MessageSender
import com.example.ui.state.ToolExecutionEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class FizaViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val nativeActionHandler = NativeActionHandler(context)
    private val geminiService = GeminiService(nativeActionHandler)

    private val _uiState = MutableStateFlow(FizaAssistantUiState())
    val uiState: StateFlow<FizaAssistantUiState> = _uiState.asStateFlow()

    private var customApiKey: String? = null

    private val ttsEngine: TextToSpeechEngine = TextToSpeechEngine(
        context = context,
        onSpeechStarted = {
            _uiState.update { it.copy(status = AssistantStatus.SPEAKING) }
        },
        onSpeechFinished = {
            _uiState.update {
                if (it.status == AssistantStatus.SPEAKING) {
                    it.copy(status = AssistantStatus.IDLE)
                } else {
                    it
                }
            }
        },
        onSpeechError = { errorMsg ->
            _uiState.update {
                it.copy(
                    status = AssistantStatus.IDLE,
                    errorMessage = errorMsg
                )
            }
        }
    )

    private val audioStreamer: AudioStreamer = AudioStreamer(
        context = context,
        onSpeechRecognized = { text ->
            processSpokenText(text)
        },
        onPartialTranscript = { partial ->
            _uiState.update { it.copy(userSpeechTranscript = partial) }
        },
        onRmsLevelChanged = { rms ->
            _uiState.update { it.copy(rmsAudioLevel = rms) }
        },
        onListeningStarted = {
            _uiState.update {
                it.copy(
                    status = AssistantStatus.LISTENING,
                    errorMessage = null,
                    userSpeechTranscript = "Listening..."
                )
            }
        },
        onListeningEnded = {
            _uiState.update {
                if (it.status == AssistantStatus.LISTENING) {
                    it.copy(rmsAudioLevel = 0f)
                } else {
                    it
                }
            }
        },
        onError = { error ->
            _uiState.update {
                it.copy(
                    status = AssistantStatus.IDLE,
                    errorMessage = error,
                    rmsAudioLevel = 0f
                )
            }
        }
    )

    init {
        ttsEngine.setVoiceParams(
            pitch = _uiState.value.voicePitch,
            rate = _uiState.value.voicePace,
            language = _uiState.value.selectedLanguage
        )
        audioStreamer.setLanguage(_uiState.value.selectedLanguage)
    }

    fun toggleListening() {
        if (_uiState.value.status == AssistantStatus.SPEAKING) {
            // Barge-in: immediately cancel speech and listen
            bargeIn()
            return
        }

        if (_uiState.value.status == AssistantStatus.LISTENING) {
            audioStreamer.stopListening()
            _uiState.update { it.copy(status = AssistantStatus.IDLE) }
        } else {
            ttsEngine.stop()
            audioStreamer.startListening()
        }
    }

    fun bargeIn() {
        ttsEngine.stop()
        audioStreamer.startListening()
    }

    fun stopSpeaking() {
        ttsEngine.stop()
        _uiState.update { it.copy(status = AssistantStatus.IDLE) }
    }

    fun processSpokenText(text: String) {
        if (text.isBlank()) return

        val userMessage = ConversationMessage(
            sender = MessageSender.USER,
            text = text
        )

        _uiState.update {
            it.copy(
                status = AssistantStatus.PROCESSING,
                userSpeechTranscript = text,
                history = it.history + userMessage
            )
        }

        viewModelScope.launch {
            try {
                val response = geminiService.processUserSpeech(
                    userText = text,
                    customApiKey = customApiKey,
                    onToolExecuted = { event: ToolExecutionEvent ->
                        _uiState.update { state ->
                            state.copy(activeTool = event)
                        }
                    }
                )

                val assistantMessage = ConversationMessage(
                    sender = MessageSender.FIZA,
                    text = response,
                    toolEvent = _uiState.value.activeTool
                )

                _uiState.update {
                    it.copy(
                        fizaResponseText = response,
                        history = it.history + assistantMessage,
                        status = AssistantStatus.SPEAKING
                    )
                }

                ttsEngine.speak(response)
            } catch (e: Exception) {
                val errorMsg = "Oops! Something went wrong: ${e.message}"
                _uiState.update {
                    it.copy(
                        status = AssistantStatus.ERROR,
                        errorMessage = errorMsg,
                        fizaResponseText = errorMsg
                    )
                }
                ttsEngine.speak("Sorry, I ran into a glitch. Try asking again!")
            }
        }
    }

    fun sendTextCommand(command: String) {
        processSpokenText(command)
    }

    fun toggleBackgroundService() {
        val nextState = !_uiState.value.isBackgroundServiceRunning
        if (nextState) {
            FizaVoiceService.startService(context)
        } else {
            FizaVoiceService.stopService(context)
        }
        _uiState.update { it.copy(isBackgroundServiceRunning = nextState) }
    }

    fun updateLanguage(language: String) {
        _uiState.update { it.copy(selectedLanguage = language) }
        ttsEngine.setVoiceParams(
            pitch = _uiState.value.voicePitch,
            rate = _uiState.value.voicePace,
            language = language
        )
        audioStreamer.setLanguage(language)
    }

    fun updateVoiceTuning(pitch: Float, pace: Float) {
        _uiState.update { it.copy(voicePitch = pitch, voicePace = pace) }
        ttsEngine.setVoiceParams(
            pitch = pitch,
            rate = pace,
            language = _uiState.value.selectedLanguage
        )
    }

    fun setCustomApiKey(key: String) {
        customApiKey = key.trim()
    }

    fun updatePermissions(
        audio: Boolean,
        contacts: Boolean,
        location: Boolean,
        notifications: Boolean,
        call: Boolean
    ) {
        _uiState.update {
            it.copy(
                hasAudioPermission = audio,
                hasContactsPermission = contacts,
                hasLocationPermission = location,
                hasNotificationPermission = notifications,
                hasCallPermission = call
            )
        }
    }

    fun showPermissionsDialog(show: Boolean) {
        _uiState.update { it.copy(showPermissionSheet = show) }
    }

    fun showSettingsDialog(show: Boolean) {
        _uiState.update { it.copy(showSettingsSheet = show) }
    }

    fun showHistoryDialog(show: Boolean) {
        _uiState.update { it.copy(showHistorySheet = show) }
    }

    fun clearHistory() {
        geminiService.clearHistory()
        _uiState.update {
            it.copy(
                history = emptyList(),
                activeTool = null,
                fizaResponseText = "Fresh start! What can I do for you?"
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioStreamer.destroy()
        ttsEngine.shutdown()
    }
}
