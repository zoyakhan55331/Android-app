package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.state.AssistantStatus
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlitchRed
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeuralPink
import com.example.ui.theme.VoidBlack
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FuturisticOrb(
    status: AssistantStatus,
    audioLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_infinite")

    // Continuous rotation for orbital energy rings
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbital_rotation"
    )

    val counterRotationAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbital_counter_rotation"
    )

    // Breathing pulse for ambient state
    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ambient_breathing"
    )

    // Dynamic color matching the assistant state
    val primaryGlowColor by animateColorAsState(
        targetValue = when (status) {
            AssistantStatus.LISTENING -> NeonCyan
            AssistantStatus.PROCESSING -> ElectricViolet
            AssistantStatus.SPEAKING -> NeuralPink
            AssistantStatus.ERROR -> GlitchRed
            AssistantStatus.CONNECTING -> CyberAmber
            AssistantStatus.IDLE -> NeonCyan
            AssistantStatus.DISCONNECTED -> Color.Gray
        },
        animationSpec = tween(durationMillis = 400),
        label = "orb_color_primary"
    )

    val secondaryGlowColor by animateColorAsState(
        targetValue = when (status) {
            AssistantStatus.LISTENING -> MatrixGreen
            AssistantStatus.PROCESSING -> NeuralPink
            AssistantStatus.SPEAKING -> ElectricViolet
            AssistantStatus.ERROR -> CyberAmber
            AssistantStatus.CONNECTING -> ElectricViolet
            AssistantStatus.IDLE -> ElectricViolet
            AssistantStatus.DISCONNECTED -> Color.DarkGray
        },
        animationSpec = tween(durationMillis = 400),
        label = "orb_color_secondary"
    )

    val dynamicPulse = if (status == AssistantStatus.LISTENING || status == AssistantStatus.SPEAKING) {
        1f + (audioLevel * 0.45f)
    } else {
        breathingScale
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(260.dp)
            .testTag("fiza_orb_button")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 130.dp),
                onClick = onClick
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2.6f) * dynamicPulse

            // 1. Outermost Diffuse Energy Aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlowColor.copy(alpha = 0.35f),
                        secondaryGlowColor.copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.65f
                ),
                radius = baseRadius * 1.65f,
                center = center
            )

            // 2. Middle Pulsing Wave Ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        secondaryGlowColor.copy(alpha = 0.45f),
                        primaryGlowColor.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.25f
                ),
                radius = baseRadius * 1.25f,
                center = center
            )

            // 3. Orbital Ring 1 with Cyberspace nodes
            val orbitalRadius1 = baseRadius * 1.18f
            val radAngle1 = Math.toRadians(rotationAngle.toDouble())
            drawCircle(
                color = primaryGlowColor.copy(alpha = 0.55f),
                radius = orbitalRadius1,
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Orbital satellites on Ring 1
            val sat1X = center.x + (orbitalRadius1 * cos(radAngle1)).toFloat()
            val sat1Y = center.y + (orbitalRadius1 * sin(radAngle1)).toFloat()
            drawCircle(
                color = primaryGlowColor,
                radius = 5.dp.toPx(),
                center = Offset(sat1X, sat1Y)
            )

            val sat1OppX = center.x - (orbitalRadius1 * cos(radAngle1)).toFloat()
            val sat1OppY = center.y - (orbitalRadius1 * sin(radAngle1)).toFloat()
            drawCircle(
                color = secondaryGlowColor,
                radius = 4.dp.toPx(),
                center = Offset(sat1OppX, sat1OppY)
            )

            // 4. Counter-rotating Orbital Ring 2 (Dashed/Segmented look)
            val orbitalRadius2 = baseRadius * 1.35f
            val radAngle2 = Math.toRadians(counterRotationAngle.toDouble())
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        primaryGlowColor.copy(alpha = 0.8f),
                        Color.Transparent,
                        secondaryGlowColor.copy(alpha = 0.8f),
                        Color.Transparent
                    ),
                    center = center
                ),
                startAngle = counterRotationAngle,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(center.x - orbitalRadius2, center.y - orbitalRadius2),
                size = androidx.compose.ui.geometry.Size(orbitalRadius2 * 2, orbitalRadius2 * 2),
                style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
            )

            val sat2X = center.x + (orbitalRadius2 * cos(radAngle2)).toFloat()
            val sat2Y = center.y + (orbitalRadius2 * sin(radAngle2)).toFloat()
            drawCircle(
                color = secondaryGlowColor,
                radius = 4.5.dp.toPx(),
                center = Offset(sat2X, sat2Y)
            )

            // 5. Core Futuristic Glowing Sphere
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        primaryGlowColor,
                        secondaryGlowColor,
                        VoidBlack
                    ),
                    center = Offset(center.x - baseRadius * 0.25f, center.y - baseRadius * 0.25f),
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center
            )

            // 6. Surface Energy Ring
            drawCircle(
                color = Color.White.copy(alpha = 0.4f),
                radius = baseRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Center Icon Indicator
        val icon = when (status) {
            AssistantStatus.LISTENING -> Icons.Filled.Mic
            AssistantStatus.SPEAKING -> Icons.Filled.VolumeUp
            AssistantStatus.PROCESSING -> Icons.Rounded.AutoAwesome
            AssistantStatus.ERROR -> Icons.Filled.MicOff
            else -> Icons.Filled.Mic
        }

        Icon(
            imageVector = icon,
            contentDescription = "Fiza Voice Action Indicator",
            tint = Color.White,
            modifier = Modifier.size(36.dp)
        )
    }
}
