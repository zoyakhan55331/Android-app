package com.example.ui.state

enum class AssistantStatus {
    DISCONNECTED,
    CONNECTING,
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

enum class MessageSender {
    USER,
    FIZA,
    SYSTEM
}

data class ToolExecutionEvent(
    val id: String = java.util.UUID.randomUUID().toString(),
    val toolName: String,
    val arguments: Map<String, String>,
    val result: String,
    val isSuccess: Boolean = true,
    val timestamp: Long = System.currentTimeMillis(),
    val iconName: String = "flash"
)

data class ConversationMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val toolEvent: ToolExecutionEvent? = null
)

data class ContactInfo(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val photoUri: String? = null
)

data class FizaAssistantUiState(
    val status: AssistantStatus = AssistantStatus.IDLE,
    val rmsAudioLevel: Float = 0f,
    val userSpeechTranscript: String = "",
    val fizaResponseText: String = "Hey there! I'm Fiza. Tap the orb or say what you need!",
    val history: List<ConversationMessage> = emptyList(),
    val activeTool: ToolExecutionEvent? = null,
    val errorMessage: String? = null,
    val isBackgroundServiceRunning: Boolean = false,
    val selectedLanguage: String = "Auto (Hinglish / English / Hindi)",
    val voicePace: Float = 1.05f,
    val voicePitch: Float = 1.15f,
    val isMicMuted: Boolean = false,
    val hasAudioPermission: Boolean = false,
    val hasContactsPermission: Boolean = false,
    val hasLocationPermission: Boolean = false,
    val hasNotificationPermission: Boolean = false,
    val hasCallPermission: Boolean = false,
    val showPermissionSheet: Boolean = false,
    val showSettingsSheet: Boolean = false,
    val showHistorySheet: Boolean = false
)
