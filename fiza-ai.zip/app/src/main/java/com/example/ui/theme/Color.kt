package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep obsidian futuristic palette
val VoidBlack = Color(0xFF060810)
val CyberDark = Color(0xFF0B0F19)
val CyberSurface = Color(0xFF131929)
val CyberSurfaceVariant = Color(0xFF1C243B)
val CyberBorder = Color(0xFF283452)

// Neon & Energy Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDark = Color(0xFF0099A8)
val NeonCyanGlow = Color(0x3300F0FF)

val ElectricViolet = Color(0xFFA855F7)
val DeepViolet = Color(0xFF7C3AED)
val VioletGlow = Color(0x33A855F7)

val NeuralPink = Color(0xFFFF2E93)
val MatrixGreen = Color(0xFF10B981)
val CyberAmber = Color(0xFFF59E0B)
val GlitchRed = Color(0xFFEF4444)

// Text and Content
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextNeon = Color(0xFFE0F2FE)

val TranslucentGlass = Color(0xCC0E1526)
val TranslucentCard = Color(0x99131C30)
