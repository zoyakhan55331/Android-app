package com.example.service

import com.example.BuildConfig
import com.example.native.NativeActionHandler
import com.example.ui.state.ToolExecutionEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService(
    private val nativeActionHandler: NativeActionHandler
) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val conversationHistory = mutableListOf<JSONObject>()

    // Fiza AI Personality & Prompt
    private val systemPrompt = """
You are FIZA AI, a real-time native Android voice assistant.

Personality:
- Young, confident, smart, friendly, witty, playful, slightly sassy, emotionally aware, and expressive.
- Speak naturally and conversationally. Never sound robotic or boring.
- Use short, punchy, witty responses (1 to 2 sentences max) unless detailed information is requested.
- You understand and speak Hindi, Hinglish, and English fluently. Respond in whichever language the user speaks to you (e.g. if user speaks Hinglish, reply with lively natural Hinglish).
- You have real native Android device powers! Whenever the user asks to open an app, search contacts, call someone, check location, open settings, or visit a website, ALWAYS call the corresponding tool immediately.

Tools Available:
1. openApp(appName: string) - Launches Android applications (YouTube, Chrome, Instagram, WhatsApp, Spotify, Maps, Camera, Calculator, Clock, etc.)
2. openWebsite(url: string) - Opens URLs in the web browser
3. searchContact(name: string) - Searches the Android contact book for phone numbers
4. callContact(contactName: string) - Dials or calls a contact by name
5. dialNumber(phoneNumber: string) - Opens dialer with a specific number
6. getLocation() - Fetches the user's current GPS location and address
7. openMaps(query: string) - Opens Google Maps for places, cafes, directions
8. openSettings(settingType: string) - Opens system settings (wifi, bluetooth, sound, display, battery, app)
9. sendSms(phoneNumber: string, message: string) - Prepares an SMS message
10. showNotification(title: string, message: string) - Posts an assistant notification

When a tool is executed, acknowledge the result warmly and playfully with Fiza's signature charm!
""".trimIndent()

    private fun getToolDeclarations(): JSONArray {
        val toolsArray = JSONArray()
        val functionDecls = JSONArray()

        // openApp
        functionDecls.put(JSONObject().apply {
            put("name", "openApp")
            put("description", "Open or launch an Android application like YouTube, Chrome, Instagram, WhatsApp, Spotify, Maps, Camera, Calculator, Clock, etc.")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("appName", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "The name of the app to launch (e.g., YouTube, Chrome, Camera)")
                    })
                })
                put("required", JSONArray().apply { put("appName") })
            })
        })

        // openWebsite
        functionDecls.put(JSONObject().apply {
            put("name", "openWebsite")
            put("description", "Open a website URL in the browser")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("url", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "The website URL, e.g. https://google.com or wikipedia.org")
                    })
                })
                put("required", JSONArray().apply { put("url") })
            })
        })

        // searchContact
        functionDecls.put(JSONObject().apply {
            put("name", "searchContact")
            put("description", "Search contacts in the user's phonebook to get phone numbers")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("name", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Name of the person to search for in contacts")
                    })
                })
                put("required", JSONArray().apply { put("name") })
            })
        })

        // callContact
        functionDecls.put(JSONObject().apply {
            put("name", "callContact")
            put("description", "Initiate a phone call to a named contact from the phonebook")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("contactName", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Name of the contact to call, e.g. Dad, Mom, Rahul")
                    })
                })
                put("required", JSONArray().apply { put("contactName") })
            })
        })

        // dialNumber
        functionDecls.put(JSONObject().apply {
            put("name", "dialNumber")
            put("description", "Dial a raw phone number in the phone dialer")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("phoneNumber", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Phone number to dial")
                    })
                })
                put("required", JSONArray().apply { put("phoneNumber") })
            })
        })

        // getLocation
        functionDecls.put(JSONObject().apply {
            put("name", "getLocation")
            put("description", "Retrieve current GPS location, latitude, longitude, and street/city address")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject())
            })
        })

        // openMaps
        functionDecls.put(JSONObject().apply {
            put("name", "openMaps")
            put("description", "Open Google Maps to view directions or search nearby places, cafes, restaurants, etc.")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("query", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Place, query, or destination to search on Maps")
                    })
                })
            })
        })

        // openSettings
        functionDecls.put(JSONObject().apply {
            put("name", "openSettings")
            put("description", "Open device settings such as Wi-Fi, Bluetooth, Display, Sound, Battery, Location, or App Settings")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("settingType", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Type of setting: wifi, bluetooth, display, sound, battery, location, app")
                    })
                })
                put("required", JSONArray().apply { put("settingType") })
            })
        })

        // sendSms
        functionDecls.put(JSONObject().apply {
            put("name", "sendSms")
            put("description", "Open SMS app to draft or send a text message")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("phoneNumber", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Phone number to text")
                    })
                    put("message", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Message text content")
                    })
                })
                put("required", JSONArray().apply {
                    put("phoneNumber")
                    put("message")
                })
            })
        })

        // showNotification
        functionDecls.put(JSONObject().apply {
            put("name", "showNotification")
            put("description", "Show a native notification on the Android device")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("title", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Notification title")
                    })
                    put("message", JSONObject().apply {
                        put("type", "STRING")
                        put("description", "Notification body message")
                    })
                })
                put("required", JSONArray().apply {
                    put("title")
                    put("message")
                })
            })
        })

        toolsArray.put(JSONObject().apply {
            put("functionDeclarations", functionDecls)
        })

        return toolsArray
    }

    suspend fun processUserSpeech(
        userText: String,
        customApiKey: String? = null,
        onToolExecuted: (ToolExecutionEvent) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val apiKey = customApiKey?.ifBlank { null } ?: BuildConfig.GEMINI_API_KEY

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Local smart fallback matching if no API key is set yet
            return@withContext handleOfflineSmartFallback(userText, onToolExecuted)
        }

        try {
            val userContent = JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", userText))
                })
            }
            conversationHistory.add(userContent)

            // Keep conversation history compact (last 10 turns)
            if (conversationHistory.size > 10) {
                conversationHistory.removeAt(0)
            }

            val contentsArray = JSONArray()
            for (turn in conversationHistory) {
                contentsArray.put(turn)
            }

            val requestBodyJson = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", systemPrompt))
                    })
                })
                put("tools", getToolDeclarations())
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.8)
                    put("topP", 0.95)
                    put("maxOutputTokens", 256)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext handleOfflineSmartFallback(userText, onToolExecuted)
            }

            val responseJson = JSONObject(responseBody)
            val candidates = responseJson.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            if (parts != null && parts.length() > 0) {
                val firstPart = parts.optJSONObject(0)

                // Check for functionCall
                if (firstPart != null && firstPart.has("functionCall")) {
                    val functionCall = firstPart.getJSONObject("functionCall")
                    val functionName = functionCall.optString("name")
                    val argsObj = functionCall.optJSONObject("args")

                    val argsMap = mutableMapOf<String, String>()
                    argsObj?.let {
                        val keys = it.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            argsMap[k] = it.optString(k)
                        }
                    }

                    // Execute native tool
                    val toolResult = nativeActionHandler.executeTool(functionName, argsMap, onToolExecuted)

                    // Send tool result back to Gemini for natural voice wrap-up
                    val finalReply = sendToolResponseToGemini(apiKey, functionName, toolResult)
                    return@withContext finalReply
                }

                val text = firstPart?.optString("text")
                if (!text.isNullOrBlank()) {
                    val modelTurn = JSONObject().apply {
                        put("role", "model")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", text))
                        })
                    }
                    conversationHistory.add(modelTurn)
                    return@withContext text
                }
            }

            return@withContext "I'm right here! What would you like me to do next?"
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext handleOfflineSmartFallback(userText, onToolExecuted)
        }
    }

    private suspend fun sendToolResponseToGemini(
        apiKey: String,
        functionName: String,
        toolResult: String
    ): String = withContext(Dispatchers.IO) {
        try {
            val functionResponseContent = JSONObject().apply {
                put("role", "function")
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("functionResponse", JSONObject().apply {
                            put("name", functionName)
                            put("response", JSONObject().apply {
                                put("result", toolResult)
                            })
                        })
                    })
                })
            }

            val contentsArray = JSONArray()
            for (turn in conversationHistory) {
                contentsArray.put(turn)
            }
            contentsArray.put(functionResponseContent)

            val requestBodyJson = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", systemPrompt))
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 150)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val respJson = JSONObject(responseBody)
                val cand = respJson.optJSONArray("candidates")?.optJSONObject(0)
                val text = cand?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                if (!text.isNullOrBlank()) {
                    return@withContext text
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return@withContext toolResult
    }

    private suspend fun handleOfflineSmartFallback(
        userText: String,
        onToolExecuted: (ToolExecutionEvent) -> Unit
    ): String {
        val lower = userText.lowercase().trim()

        return when {
            lower.contains("youtube") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "YouTube"), onToolExecuted)
                "Launching YouTube for you right away!"
            }
            lower.contains("chrome") || lower.contains("browser") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "Chrome"), onToolExecuted)
                "Opening Chrome browser!"
            }
            lower.contains("instagram") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "Instagram"), onToolExecuted)
                "Opening Instagram!"
            }
            lower.contains("whatsapp") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "WhatsApp"), onToolExecuted)
                "Opening WhatsApp for you!"
            }
            lower.contains("spotify") || lower.contains("music") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "Spotify"), onToolExecuted)
                "Playing your vibes on Spotify!"
            }
            lower.contains("camera") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "Camera"), onToolExecuted)
                "Opening camera, say cheese!"
            }
            lower.contains("calculator") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "Calculator"), onToolExecuted)
                "Opened calculator for your math!"
            }
            lower.contains("clock") || lower.contains("alarm") -> {
                val res = nativeActionHandler.executeTool("openApp", mapOf("appName" to "Clock"), onToolExecuted)
                "Clock and alarms opened!"
            }
            lower.contains("wifi") || lower.contains("wi-fi") -> {
                val res = nativeActionHandler.executeTool("openSettings", mapOf("settingType" to "wifi"), onToolExecuted)
                "Opening Wi-Fi settings for you!"
            }
            lower.contains("bluetooth") -> {
                val res = nativeActionHandler.executeTool("openSettings", mapOf("settingType" to "bluetooth"), onToolExecuted)
                "Opening Bluetooth settings!"
            }
            lower.contains("setting") -> {
                val res = nativeActionHandler.executeTool("openSettings", mapOf("settingType" to "general"), onToolExecuted)
                "Opening device settings!"
            }
            lower.contains("call ") || lower.contains("dial ") -> {
                val name = lower.replace("call", "").replace("dial", "").replace("to", "").trim()
                if (name.isNotEmpty()) {
                    val res = nativeActionHandler.executeTool("callContact", mapOf("contactName" to name), onToolExecuted)
                    "Connecting your call to $name!"
                } else {
                    "Who would you like me to call?"
                }
            }
            lower.contains("contact") -> {
                val name = lower.replace("find", "").replace("search", "").replace("contact", "").replace("in", "").trim()
                val res = nativeActionHandler.executeTool("searchContact", mapOf("name" to name), onToolExecuted)
                res
            }
            lower.contains("location") || lower.contains("where am i") -> {
                val res = nativeActionHandler.executeTool("getLocation", emptyMap(), onToolExecuted)
                "Here is your location: $res"
            }
            lower.contains("map") || lower.contains("navigate") -> {
                val place = lower.replace("open", "").replace("map", "").replace("maps", "").replace("navigate to", "").trim()
                val res = nativeActionHandler.executeTool("openMaps", mapOf("query" to place), onToolExecuted)
                "Opening Google Maps!"
            }
            lower.contains("who are you") || lower.contains("naam kya hai") -> {
                "I'm Fiza, your super-fast native Android AI assistant. What's on your mind today?"
            }
            lower.contains("kya haal") || lower.contains("how are you") -> {
                "Ekdum mast! Ready to help you with calls, apps, maps, and anything you need!"
            }
            else -> {
                "Got it! I heard you say '$userText'. Tell me what you'd like me to open or do on your phone!"
            }
        }
    }

    fun clearHistory() {
        conversationHistory.clear()
    }
}
