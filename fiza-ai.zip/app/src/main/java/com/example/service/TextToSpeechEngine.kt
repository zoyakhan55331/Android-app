package com.example.service

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class TextToSpeechEngine(
    private val context: Context,
    private val onSpeechStarted: () -> Unit = {},
    private val onSpeechFinished: () -> Unit = {},
    private val onSpeechError: (String) -> Unit = {}
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var pendingText: String? = null

    private var currentPitch = 1.15f // Slightly youthful and expressive
    private var currentRate = 1.05f  // Fluent, brisk, conversational

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupVoice()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    onSpeechStarted()
                }

                override fun onDone(utteranceId: String?) {
                    onSpeechFinished()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onSpeechError("TTS Speech Error")
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    onSpeechError("TTS Error Code: $errorCode")
                }
            })

            pendingText?.let {
                speak(it)
                pendingText = null
            }
        } else {
            isInitialized = false
            onSpeechError("Failed to initialize Text-to-Speech engine")
        }
    }

    private fun setupVoice(languagePref: String = "Auto") {
        tts?.let { engine ->
            val locale = when {
                languagePref.contains("Hindi", ignoreCase = true) -> Locale("hi", "IN")
                languagePref.contains("English", ignoreCase = true) -> Locale.ENGLISH
                else -> {
                    // Default to Indian English or UK/US if available for natural Hinglish pronunciation
                    val inLocale = Locale("en", "IN")
                    if (engine.isLanguageAvailable(inLocale) >= TextToSpeech.LANG_AVAILABLE) {
                        inLocale
                    } else {
                        Locale.ENGLISH
                    }
                }
            }

            try {
                val res = engine.setLanguage(locale)
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(Locale.ENGLISH)
                }
            } catch (e: Exception) {
                engine.setLanguage(Locale.ENGLISH)
            }

            engine.setPitch(currentPitch)
            engine.setSpeechRate(currentRate)
        }
    }

    fun setVoiceParams(pitch: Float, rate: Float, language: String) {
        currentPitch = pitch.coerceIn(0.5f, 2.0f)
        currentRate = rate.coerceIn(0.5f, 2.0f)
        tts?.setPitch(currentPitch)
        tts?.setSpeechRate(currentRate)
        setupVoice(language)
    }

    fun speak(text: String, utteranceId: String = "fiza_resp_${System.currentTimeMillis()}") {
        val cleanText = text
            .replace(Regex("\\*\\*|\\*|_|`"), "") // strip markdown artifacts for TTS
            .replace(Regex("https?://\\S+"), "link")
            .trim()

        if (cleanText.isEmpty()) {
            onSpeechFinished()
            return
        }

        if (!isInitialized) {
            pendingText = cleanText
            return
        }

        stop()

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stop() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
                onSpeechFinished()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isSpeaking(): Boolean {
        return try {
            tts?.isSpeaking ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
            isInitialized = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
