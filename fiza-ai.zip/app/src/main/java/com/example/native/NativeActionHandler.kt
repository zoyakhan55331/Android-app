package com.example.native

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.example.ui.state.ToolExecutionEvent

class NativeActionHandler(private val context: Context) {

    val appLauncher = AppLauncher(context)
    val contactsManager = ContactsManager(context)
    val locationHelper = LocationHelper(context)
    val settingsHelper = DeviceSettingsHelper(context)
    val notificationHelper = NotificationHelper(context)

    suspend fun executeTool(
        toolName: String,
        arguments: Map<String, String>,
        onToolExecuted: (ToolExecutionEvent) -> Unit
    ): String {
        var isSuccess = true
        val resultMessage = when (toolName) {
            "openWebsite" -> {
                val url = arguments["url"] ?: "https://google.com"
                val (ok, res) = appLauncher.openWebsite(url)
                isSuccess = ok
                res
            }

            "openApp" -> {
                val appName = arguments["appName"] ?: "YouTube"
                val (ok, res) = appLauncher.openApp(appName)
                isSuccess = ok
                res
            }

            "searchContact" -> {
                val name = arguments["name"] ?: ""
                if (!contactsManager.hasPermission()) {
                    isSuccess = false
                    "Contacts permission not granted. Please allow Contacts permission to find contacts."
                } else if (name.isBlank()) {
                    isSuccess = false
                    "Contact name not provided."
                } else {
                    val contact = contactsManager.findContactByName(name)
                    if (contact != null) {
                        "Found contact: ${contact.name} with phone number ${contact.phoneNumber}"
                    } else {
                        val matches = contactsManager.searchContacts(name)
                        if (matches.isNotEmpty()) {
                            val list = matches.take(3).joinToString(", ") { "${it.name} (${it.phoneNumber})" }
                            "Multiple contacts found: $list"
                        } else {
                            isSuccess = false
                            "No contact found matching '$name' in your phonebook."
                        }
                    }
                }
            }

            "dialNumber" -> {
                val number = arguments["phoneNumber"] ?: ""
                if (number.isBlank()) {
                    isSuccess = false
                    "Phone number is missing."
                } else {
                    val (ok, res) = dialPhoneNumber(number)
                    isSuccess = ok
                    res
                }
            }

            "callContact" -> {
                val name = arguments["contactName"] ?: ""
                if (name.isBlank()) {
                    isSuccess = false
                    "Please specify who you want to call."
                } else if (!contactsManager.hasPermission()) {
                    isSuccess = false
                    "Contacts permission required to find $name's number."
                } else {
                    val contact = contactsManager.findContactByName(name)
                    if (contact != null) {
                        val (ok, res) = dialPhoneNumber(contact.phoneNumber)
                        isSuccess = ok
                        if (ok) "Dialing ${contact.name} (${contact.phoneNumber})" else res
                    } else {
                        isSuccess = false
                        "Could not find '$name' in your contacts to call."
                    }
                }
            }

            "getLocation" -> {
                val loc = locationHelper.getCurrentLocation()
                loc
            }

            "openMaps" -> {
                val query = arguments["query"] ?: arguments["place"]
                val (ok, res) = locationHelper.openMaps(query)
                isSuccess = ok
                res
            }

            "openSettings" -> {
                val settingType = arguments["settingType"] ?: arguments["setting"] ?: "general"
                val (ok, res) = settingsHelper.openSettings(settingType)
                isSuccess = ok
                res
            }

            "sendSms" -> {
                val phone = arguments["phoneNumber"] ?: ""
                val message = arguments["message"] ?: ""
                val (ok, res) = openSms(phone, message)
                isSuccess = ok
                res
            }

            "showNotification" -> {
                val title = arguments["title"] ?: "Fiza AI"
                val message = arguments["message"] ?: "Assistant update"
                val (ok, res) = notificationHelper.showNotification(title, message)
                isSuccess = ok
                res
            }

            else -> {
                isSuccess = false
                "Unknown tool: $toolName"
            }
        }

        val event = ToolExecutionEvent(
            toolName = toolName,
            arguments = arguments,
            result = resultMessage,
            isSuccess = isSuccess,
            iconName = when (toolName) {
                "openApp" -> "apps"
                "openWebsite" -> "web"
                "searchContact", "callContact" -> "contacts"
                "dialNumber" -> "phone"
                "getLocation", "openMaps" -> "map"
                "openSettings" -> "settings"
                "sendSms" -> "sms"
                "showNotification" -> "notification"
                else -> "flash"
            }
        )

        onToolExecuted(event)
        return resultMessage
    }

    private fun dialPhoneNumber(phoneNumber: String): Pair<Boolean, String> {
        return try {
            val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "")
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Dialing $cleanPhone")
        } catch (e: Exception) {
            Pair(false, "Failed to open phone dialer: ${e.message}")
        }
    }

    private fun openSms(phoneNumber: String, messageText: String): Pair<Boolean, String> {
        return try {
            val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "")
            val uri = Uri.parse("smsto:$cleanPhone")
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", messageText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Drafted SMS to $phoneNumber")
        } catch (e: Exception) {
            Pair(false, "Failed to open SMS app: ${e.message}")
        }
    }
}
