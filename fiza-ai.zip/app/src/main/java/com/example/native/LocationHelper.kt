package com.example.native

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

class LocationHelper(private val context: Context) {

    fun hasPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    suspend fun getCurrentLocation(): String {
        if (!hasPermission()) {
            return "Location permission not granted. Please allow location access."
        }

        val fusedClient = LocationServices.getFusedLocationProviderClient(context)

        return suspendCancellableCoroutine { continuation ->
            try {
                fusedClient.lastLocation.addOnSuccessListener { location: Location? ->
                    if (location != null) {
                        val addressStr = getAddressFromLocation(location.latitude, location.longitude)
                        continuation.resume("Latitude: ${location.latitude}, Longitude: ${location.longitude}. $addressStr")
                    } else {
                        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                        val lastGps = try {
                            lm?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                                ?: lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                        } catch (e: SecurityException) {
                            null
                        }

                        if (lastGps != null) {
                            val addr = getAddressFromLocation(lastGps.latitude, lastGps.longitude)
                            continuation.resume("Latitude: ${lastGps.latitude}, Longitude: ${lastGps.longitude}. $addr")
                        } else {
                            continuation.resume("Location currently unavailable. Please ensure GPS is enabled.")
                        }
                    }
                }.addOnFailureListener { e ->
                    continuation.resume("Failed to retrieve location: ${e.message}")
                }
            } catch (e: SecurityException) {
                continuation.resume("Security error retrieving location: ${e.message}")
            } catch (e: Exception) {
                continuation.resume("Error retrieving location: ${e.message}")
            }
        }
    }

    private fun getAddressFromLocation(lat: Double, lng: Double): String {
        return try {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                val locality = addr.locality ?: addr.subAdminArea ?: ""
                val adminArea = addr.adminArea ?: ""
                val country = addr.countryName ?: ""
                val feature = addr.featureName ?: ""
                "Location: $feature, $locality, $adminArea, $country".trim().removePrefix(",")
            } else {
                "Coordinates: ($lat, $lng)"
            }
        } catch (e: Exception) {
            "Coordinates: ($lat, $lng)"
        }
    }

    fun openMaps(query: String? = null): Pair<Boolean, String> {
        return try {
            val uri = if (query.isNullOrBlank()) {
                Uri.parse("geo:0,0?q=")
            } else {
                Uri.parse("geo:0,0?q=" + Uri.encode(query))
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, if (query.isNullOrBlank()) "Opened Maps" else "Opened Maps for '$query'")
        } catch (e: Exception) {
            Pair(false, "Could not open Google Maps: ${e.message}")
        }
    }
}
