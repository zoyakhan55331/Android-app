package com.example.native

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID_ASSISTANT = "fiza_assistant_notifications"
        const val CHANNEL_NAME_ASSISTANT = "Fiza AI Alerts"
        const val CHANNEL_ID_FOREGROUND = "fiza_foreground_service"
        const val CHANNEL_NAME_FOREGROUND = "Fiza AI Background Assistant"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val assistantChannel = NotificationChannel(
                CHANNEL_ID_ASSISTANT,
                CHANNEL_NAME_ASSISTANT,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for Fiza AI assistant tool actions and reminders"
                enableLights(true)
            }

            val fgChannel = NotificationChannel(
                CHANNEL_ID_FOREGROUND,
                CHANNEL_NAME_FOREGROUND,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent background voice listener service notification"
            }

            notificationManager.createNotificationChannel(assistantChannel)
            notificationManager.createNotificationChannel(fgChannel)
        }
    }

    fun showNotification(title: String, message: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID_ASSISTANT)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build()

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify((System.currentTimeMillis() % 10000).toInt(), notification)

            Pair(true, "Notification posted: '$title'")
        } catch (e: Exception) {
            Pair(false, "Failed to post notification: ${e.message}")
        }
    }
}
