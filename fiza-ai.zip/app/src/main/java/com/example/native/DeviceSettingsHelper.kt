package com.example.native

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

class DeviceSettingsHelper(private val context: Context) {

    fun openSettings(settingType: String): Pair<Boolean, String> {
        val cleanType = settingType.trim().lowercase()
        val action = when {
            cleanType.contains("wifi") || cleanType.contains("wi-fi") || cleanType.contains("network") || cleanType.contains("internet") -> {
                Settings.ACTION_WIFI_SETTINGS
            }
            cleanType.contains("bluetooth") || cleanType.contains("bt") -> {
                Settings.ACTION_BLUETOOTH_SETTINGS
            }
            cleanType.contains("display") || cleanType.contains("screen") || cleanType.contains("brightness") -> {
                Settings.ACTION_DISPLAY_SETTINGS
            }
            cleanType.contains("sound") || cleanType.contains("volume") || cleanType.contains("audio") || cleanType.contains("ringtone") -> {
                Settings.ACTION_SOUND_SETTINGS
            }
            cleanType.contains("battery") || cleanType.contains("power") -> {
                Settings.ACTION_BATTERY_SAVER_SETTINGS
            }
            cleanType.contains("location") || cleanType.contains("gps") -> {
                Settings.ACTION_LOCATION_SOURCE_SETTINGS
            }
            cleanType.contains("app") || cleanType.contains("permission") -> {
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            }
            cleanType.contains("date") || cleanType.contains("time") -> {
                Settings.ACTION_DATE_SETTINGS
            }
            cleanType.contains("airplane") || cleanType.contains("flight") -> {
                Settings.ACTION_AIRPLANE_MODE_SETTINGS
            }
            else -> {
                Settings.ACTION_SETTINGS
            }
        }

        return try {
            val intent = if (action == Settings.ACTION_APPLICATION_DETAILS_SETTINGS) {
                Intent(action).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(action).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(intent)
            Pair(true, "Opened $settingType settings")
        } catch (e: Exception) {
            try {
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                Pair(true, "Opened System Settings")
            } catch (ex: Exception) {
                Pair(false, "Failed to open settings: ${ex.message}")
            }
        }
    }
}
