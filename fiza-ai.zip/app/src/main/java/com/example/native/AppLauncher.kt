package com.example.native

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore

class AppLauncher(private val context: Context) {

    private val commonPackageMap = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "google" to "com.google.android.googlequicksearchbox",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "spotify" to "com.spotify.music",
        "camera" to "camera_intent",
        "calculator" to "com.google.android.calculator",
        "clock" to "com.google.android.deskclock",
        "alarm" to "alarm_intent",
        "gmail" to "com.google.android.gm",
        "email" to "com.google.android.gm",
        "play store" to "com.android.vending",
        "photos" to "com.google.android.apps.photos",
        "gallery" to "gallery_intent"
    )

    fun openApp(appName: String): Pair<Boolean, String> {
        val cleanName = appName.trim().lowercase()

        if (cleanName.contains("camera")) {
            return try {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                Pair(true, "Opened Camera")
            } catch (e: Exception) {
                Pair(false, "Could not open camera: ${e.message}")
            }
        }

        if (cleanName.contains("alarm") || cleanName.contains("clock")) {
            return try {
                val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                Pair(true, "Opened Clock & Alarms")
            } catch (e: Exception) {
                launchByPackageOrSearch("clock", "Clock")
            }
        }

        val directPkg = commonPackageMap[cleanName]
            ?: commonPackageMap.entries.firstOrNull { cleanName.contains(it.key) }?.value

        if (directPkg != null && directPkg != "camera_intent" && directPkg != "alarm_intent") {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(directPkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return Pair(true, "Launched $appName")
            }
        }

        return launchByPackageOrSearch(cleanName, appName)
    }

    private fun launchByPackageOrSearch(query: String, originalName: String): Pair<Boolean, String> {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        for (app in packages) {
            val appLabel = pm.getApplicationLabel(app).toString().lowercase()
            if (appLabel.contains(query) || query.contains(appLabel)) {
                val intent = pm.getLaunchIntentForPackage(app.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return Pair(true, "Launched ${pm.getApplicationLabel(app)}")
                }
            }
        }

        return Pair(false, "Could not find '$originalName' on your device. You can download it from Play Store.")
    }

    fun openWebsite(url: String): Pair<Boolean, String> {
        return try {
            val validUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
                "https://$url"
            } else {
                url
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Opened $validUrl")
        } catch (e: Exception) {
            Pair(false, "Failed to open website: ${e.message}")
        }
    }
}
